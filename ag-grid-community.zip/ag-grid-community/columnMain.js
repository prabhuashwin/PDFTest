﻿var columnDefs = [
  {
      
      headerName: 'Week3',
      headerGroupComponent: 'customHeaderGroupComponent',
      children: [
 { headerName: 'Nov Actuals', field: 'Actuals', width: 150 },
 { headerName: 'Dec Plan', columnGroupShow: 'open', field: 'W5_iplan', width: 150, filter: 'agNumberColumnFilter' },
 { headerName: 'Dec LE FHM', columnGroupShow: 'open', field: 'W5_iLE_HFM', width: 150, filter: 'agNumberColumnFilter' },
 { headerName: 'Dec Prior PA', columnGroupShow: 'open', field: '', width: 150, filter: 'agNumberColumnFilter' },
 { headerName: 'Dec MTD', columnGroupShow: 'open', field: '', width: 150, filter: 'agNumberColumnFilter' },
 { headerName: 'Dec Est', columnGroupShow: 'open', field: '', width: 150, filter: 'agNumberColumnFilter' },
 { headerName: 'Dec VP', columnGroupShow: 'open', field: '', width: 150, filter: 'agNumberColumnFilter' },
 { headerName: 'Dec Var LE FHM', columnGroupShow: 'open', field: '', width: 150, filter: 'agNumberColumnFilter' },
 { headerName: 'Dec Var Prior PA', columnGroupShow: 'open', field: '', width: 150, filter: 'agNumberColumnFilter' },
      ],
  },
  {
      headerName: 'Week4',
      headerGroupComponent: 'customHeaderGroupComponent',      
      children: [
             { headerName: '', field: '', width: 150 },
             { headerName: 'Jan Plan', columnGroupShow: 'open', field: 'W1_iplan', width: 150, filter: 'agNumberColumnFilter' },
             { headerName: 'Jan LE FHM', columnGroupShow: 'open', field: 'W1_iLE_HFM', width: 150, filter: 'agNumberColumnFilter' },
             { headerName: 'Dec Prior PA', columnGroupShow: 'open', field: 'iPriorPA', width: 150, filter: 'agNumberColumnFilter' },
             { headerName: 'Dec MTD', columnGroupShow: 'open', field: 'iMTD', width: 150, filter: 'agNumberColumnFilter' },
             { headerName: 'Dec Est', columnGroupShow: 'open', field: 'iEST', width: 150, filter: 'agNumberColumnFilter' },
             { headerName: 'Dec VP', columnGroupShow: 'open', field: 'iVP', width: 150, filter: 'agNumberColumnFilter' },
             { headerName: 'Dec Var LE FHM', columnGroupShow: 'open', field: 'iVartoLEHFM', width: 150, filter: 'agNumberColumnFilter' },
             { headerName: 'Dec Var Prior PA', columnGroupShow: 'open', field: 'iVartoPriorPA', width: 150, filter: 'agNumberColumnFilter' },
      ],
  },
];

var gridOptions = {
    components: {
        customHeaderGroupComponent: CustomHeaderGroup,
    },
    columnDefs: columnDefs,
    rowData: null,
    defaultColDef: {
        width: 100,
        resizable: true,
    },
};

function ligetRowData() {
    var rowData = [];
    gridOptions.api.forEachNode(function (node) {
        rowData.push(node.data);
    });
    console.log('Row Data:');
    console.log(rowData);

    var LIObjArray = [];    
}


// setup the grid after the page has finished loading
document.addEventListener('DOMContentLoaded', function () {
    var gridDiv = document.querySelector('#myGrid');
    new agGrid.Grid(gridDiv, gridOptions);
    gridOptions.api.setRowData(null);
    //$.getJSON("Week3.json", function (json) {
    //    gridOptions.api.setRowData(json);
    //});    
});
