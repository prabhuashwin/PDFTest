var columnDefs = [
    {
        headerName: '',
        children: [
            { headerName: 'Value Stream', field: 'SBU', width: 150, filter: 'agTextColumnFilter', pinned: 'left', rowGroup: 'true' },
            { headerName: 'Scope Of Work', field: '', width: 90, filter: 'agNumberColumnFilter', pinned: 'left' },
            { headerName: 'SCOMET License Number', field: 'SCOMETLicenseNumber', width: 120, pinned: 'left' },
            { headerName: 'Approved Budget', field: 'ApprovedBudget', width: 120, pinned: 'left' },
            {
                headerName: 'Start Date', field: 'StartDate', width: 120, pinned: 'left', valueFormatter: function (params) {
                    return moment(params.value).format('DD/MM/YYYY');
                }
            },
            {
                headerName: 'End Date', field: 'FinishDate', width: 120, pinned: 'left', valueFormatter: function (params) {
                    return moment(params.value).format('DD/MM/YYYY');
                }
            }
        ]
    },
    {
        headerName: '2018',
        children: [
            { headerName: '', field: '', width: 70 },
            { headerName: 'January', columnGroupShow: 'open', field: 'January', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'February', columnGroupShow: 'open', field: 'February', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'March', columnGroupShow: 'open', field: 'March', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'April', columnGroupShow: 'open', field: 'April', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'May', columnGroupShow: 'open', field: 'May', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'June', columnGroupShow: 'open', field: 'June', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'July', columnGroupShow: 'open', field: 'July', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'August', columnGroupShow: 'open', field: 'August', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'September', columnGroupShow: 'open', field: 'September', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'October', columnGroupShow: 'open', field: 'October', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'November', columnGroupShow: 'open', field: 'November', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'December', columnGroupShow: 'open', field: 'December', width: 100, filter: 'agNumberColumnFilter' }
        ]
    },
    {
        headerName: '2019',
        children: [
            { headerName: '', field: '', width: 70 },
            { headerName: 'January', columnGroupShow: 'open', field: 'JanuaryP1', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'February', columnGroupShow: 'open', field: 'FebruaryP1', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'March', columnGroupShow: 'open', field: 'MarchP1', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'April', columnGroupShow: 'open', field: 'AprilP1', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'May', columnGroupShow: 'open', field: 'MayP1', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'June', columnGroupShow: 'open', field: 'JuneP1', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'July', columnGroupShow: 'open', field: 'JulyP1', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'August', columnGroupShow: 'open', field: 'AugustP1', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'September', columnGroupShow: 'open', field: 'SeptemberP1', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'October', columnGroupShow: 'open', field: 'OctoberP1', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'November', columnGroupShow: 'open', field: 'NovemberP1', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'December', columnGroupShow: 'open', field: 'DecemberP1', width: 100, filter: 'agNumberColumnFilter' }
        ]
    },
    {
        headerName: '2020',
        children: [
            { headerName: '', field: '', width: 70 },
            { headerName: 'January', columnGroupShow: 'open', field: 'JanuaryP2', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'February', columnGroupShow: 'open', field: 'FebruaryP2', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'March', columnGroupShow: 'open', field: 'MarchP2', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'April', columnGroupShow: 'open', field: 'AprilP2', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'May', columnGroupShow: 'open', field: 'MayP2', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'June', columnGroupShow: 'open', field: 'JuneP2', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'July', columnGroupShow: 'open', field: 'JulyP2', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'August', columnGroupShow: 'open', field: 'AugustP2', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'September', columnGroupShow: 'open', field: 'SeptemberP2', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'October', columnGroupShow: 'open', field: 'OctoberP2', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'November', columnGroupShow: 'open', field: 'NovemberP2', width: 100, filter: 'agNumberColumnFilter' },
            { headerName: 'December', columnGroupShow: 'open', field: 'DecemberP2', width: 100, filter: 'agNumberColumnFilter' }
        ]
    },
    {
        headerName: '',
        children: [
            { headerName: 'Cumulative Actuals', field: 'athlete', width: 150, filter: 'agTextColumnFilter' },
            { headerName: 'Budget Remaining', field: 'BudgetRemaining', width: 90, filter: 'agNumberColumnFilter' },
            { headerName: 'Budget Utilized', field: 'BudgetUtilized', width: 120 },
            { headerName: 'Comments', field: 'Comments', width: 120 }
        ]
    },
];

var gridOptions = {
    defaultColDef: {
        sortable: true,
        resizable: true,
        filter: true
    },
    debug: true,
    columnDefs: columnDefs,
    rowData: null
};

// setup the grid after the page has finished loading
document.addEventListener('DOMContentLoaded', function () {
    //var gridDiv = document.querySelector('#myGrid');
    //new agGrid.Grid(gridDiv, gridOptions);
    let eGridDiv = document.querySelector('#myGrid');
    new agGrid.Grid(eGridDiv, gridOptions);

    $.getJSON("LicesnceSpent_JSON.json", function (json) {
        gridOptions.api.setRowData(json);
    });

    //agGrid.simpleHttpRequest({ url: 'https://raw.githubusercontent.com/ag-grid/ag-grid/master/packages/ag-grid-docs/src/olympicWinnersSmall.json' }).then(function (data) {
    //    console.log(data);
    //    gridOptions.api.setRowData(data);
    //});
});