var columnDefs = [
    { field: 'CR/CO ID', width: 200, chartDataType: 'series', width: 150 },
    { field: 'CR/CO NAME', width: 200, chartDataType: 'series', width: 150 },
    { field: 'CO TYPE', width: 200, chartDataType: 'series', width: 150 },
    { field: 'SOLUTION ITEM', width: 200, chartDataType: 'series', width: 150 },
    { field: 'PROGRAM', width: 200, chartDataType: 'series', width: 150 },
  { field: 'PRIORITY', width: 200, chartDataType: 'series', width: 150 },
  { field: 'CHARGE CODE', chartDataType: 'series', width: 150 },
  { field: 'DD OR TECHPUBS TEAM', chartDataType: 'series', width: 150 },
  { field: 'DD OR TECHPUBS RESOURCE', chartDataType: 'series', width: 150 },
  { field: 'TASK NAME', chartDataType: 'category', width: 150, enablePivot: true },
  { field: 'TASK STATE', chartDataType: 'series', width: 150 },
  { field: 'RESPONSIBLE USER', chartDataType: 'series', width: 150 },
  { field: 'DATE ASSIGNED', chartDataType: 'series', width: 150 },
  { field: 'COMPLETION DATE', chartDataType: 'series', width: 150 },
  { field: 'TASK TIME(Hrs)', chartDataType: 'series', width: 150 },
  { field: 'ADDRESSED CRs', chartDataType: 'series', width: 150 },
  { field: 'TASK ELAPSED TIME (Hrs)', chartDataType: 'series', width: 150 },
  { field: 'TASK ELAPSED TIME (Days)', chartDataType: 'series', width: 150 },
];

//var columnDefs = [
//  { field: 'CR/CO ID', width: 200, chartDataType: 'series', width: 150 },
//    { field: 'CR/CO NAME', width: 200, chartDataType: 'series', width: 150 },
//    { field: 'CO TYPE', width: 200, chartDataType: 'series', width: 150 },
//    { field: 'SOLUTION ITEM', width: 200, chartDataType: 'series', width: 150 },
//    { field: 'PROGRAM', width: 200, chartDataType: 'category', width: 150, rowGroup: true },
//  { field: 'PRIORITY', width: 200, chartDataType: 'series', width: 150 },
//  { field: 'CHARGE CODE', chartDataType: 'series', width: 150},
//  { field: 'DD OR TECHPUBS TEAM', chartDataType: 'series', width: 150 },
//  { field: 'DD OR TECHPUBS RESOURCE', chartDataType: 'series' },
//  { field: 'TASK NAME', chartDataType: 'series', width: 150},
//  { field: 'TASK STATE', chartDataType: 'series', width: 150},
//  { field: 'RESPONSIBLE USER', chartDataType: 'series', width: 150 },
//  { field: 'DATE ASSIGNED', chartDataType: 'series', width: 150 },
//  { field: 'COMPLETION DATE', chartDataType: 'series', width: 150 },
//  { field: 'TASK TIME(Hrs)', chartDataType: 'series', width: 150, aggFunc: 'sum' },
//  { field: 'ADDRESSED CRs', chartDataType: 'series', width: 150 },
//  { field: 'TASK ELAPSED TIME (Hrs)', chartDataType: 'series', width: 150, aggFunc: 'sum' },
//  { field: 'TASK ELAPSED TIME (Days)', chartDataType: 'series', width: 150, aggFunc: 'sum' },
//];

var gridOptions = {
    defaultColDef: {
        editable: true,
        sortable: true,
        flex: 1,
        minWidth: 200,
        filter: true,
        resizable: true,
    },
    popupParent: document.body,
    columnDefs: columnDefs,
    enableRangeSelection: true,
    enableCharts: true,
    onFirstDataRendered: onFirstDataRendered,
    chartThemeOverrides: {
        common: {
            padding: {
                top: 20,
                right: 30,
                bottom: 10,
                left: 2,
            },
            background: {
                fill: '#e5e5e5',
            },
            title: {
                enabled: true,
                text: 'EVAC Support with Teamcenter Report Charts',
                fontStyle: 'italic',
                fontWeight: '600',
                fontSize: 18,
                fontFamily: 'Impact, sans-serif',
                color: '#414182',
            },
            legend: {
                enabled: true,
                position: 'left',
                padding: 20,
                item: {
                    label: {
                        fontStyle: 'italic',
                        fontWeight: 'bold',
                        fontSize: 18,
                        fontFamily: 'Palatino, serif',
                        color: '#555',
                    },
                    marker: {
                        type: 'diamond',
                        size: 10,
                        padding: 10,
                        strokeWidth: 2,
                    },
                    paddingX: 120,
                    paddingY: 20,
                },
            },
            tooltipClass: 'my-tooltip-class',
        },
    },
    //sideBar: 'columns',
};

function sizeToFit() {
    gridOptions.api.sizeColumnsToFit();
}

function autoSizeAll(skipHeader) {
    var allColumnIds = [];
    gridOptions.columnApi.getAllColumns().forEach(function (column) {
        allColumnIds.push(column.colId);
    });

    gridOptions.columnApi.autoSizeColumns(allColumnIds, skipHeader);
}

function onFirstDataRendered(params) {
    var cellRange = {
        rowStartIndex: 0,
        rowEndIndex: 4,
        columns: ['CR/CO ID', 'CR/CO NAME', 'CO TYPE', 'SOLUTION ITEM', 'PROGRAM', 'PRIORITY', 'CHARGE CODE', 'DD OR TECHPUBS TEAM', 'DD OR TECHPUBS RESOURCE', 'TASK NAME', 'TASK STATE', 'RESPONSIBLE USER', 'RESPONSIBLE USER', 'DATE ASSIGNED', 'COMPLETION DATE', 'TASK TIME(Hrs)', 'ADDRESSED CRs', 'TASK ELAPSED TIME (Hrs)', 'TASK ELAPSED TIME (Days)'],
    };

    var createRangeChartParams = {
        cellRange: cellRange,
        chartType: 'groupedBar',
    };

    params.api.createRangeChart(createRangeChartParams);
}


document.addEventListener('DOMContentLoaded', function () {

    let eGridDiv = document.querySelector('#myGrid');
    new agGrid.Grid(eGridDiv, gridOptions);

    $.getJSON("data_filtered.json", function (json) {
        gridOptions.api.setRowData(json);
    });

});