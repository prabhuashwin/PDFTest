﻿class RowEditComponent {
    constructor() {
        this.isNew = true;
    }
    init(params) {
        this.params = params;

        this.eGui = document.createElement('div');

        this.editButton = document.createElement('button');
        this.editButton.innerHTML = 'edit';
        this.editButton.style = "background-color: #008cba"
        this.editButton.addEventListener('click', this.onEditClick.bind(this));

        this.deleteButton = document.createElement('button');
        this.deleteButton.innerHTML = 'delete';
        this.editButton.style = "background-color: #f44336"
        this.deleteButton.addEventListener('click', this.onDeleteClick.bind(this));

        this.updateButton = document.createElement('button');
        this.updateButton.innerHTML = 'update';
        this.editButton.style = "background-color: #4caf50"
        this.updateButton.addEventListener('click', this.onUpdateClick.bind(this));

        this.cancelButton = document.createElement('button');
        this.cancelButton.innerHTML = 'cancel';
        this.editButton.style = "background-color: #e7e7e7"
        this.cancelButton.addEventListener('click', this.onCancelClick.bind(this));

        this.eGui.appendChild(this.editButton);
        this.eGui.appendChild(this.deleteButton);

        this.onCancel = this.onCancelClick.bind(this);
    }

    getGui() {
        return this.eGui;
    }

    invokeParentMethod() {
        this.params.context.componentParent.methodFromParent(
          `Row: ${this.params.node.rowIndex}, Col: ${this.params.colDef.headerName}`
        );
    }

    refresh() {
        return false;
    }

    onEditClick() {
        let renderers = this.params.api.getCellRendererInstances();
        renderers.forEach(renderer => {
            if (!renderer.isNew) renderer.onCancel();
        });
        this.isNew = false;
        this.previousData = JSON.parse(JSON.stringify(this.params.node.data));
        let cols = this.params.columnApi.getAllGridColumns();
        let firstCol = {
            colId: '',
        };
        if (cols) {
            firstCol = cols[0];
        }
        let rowIndex = this.params.node.rowIndex;
        this.params.api.setFocusedCell(rowIndex, firstCol.colId);
        this.params.api.startEditingCell({
            rowIndex: rowIndex,
            colKey: 'vcPartNumber',
        });
        this.editCleanUp.call(this);
    }

    onUpdateClick() {
        this.isNew = true;
        let obj = {};
        obj.type = 'update';
        this.params.api.stopEditing();
        obj.selectedData = [this.params.data];
        this.updateAndCancelCleanUp.call(this);
    }

    onCancelClick() {
        this.isNew = true;
        this.params.node.setData(this.previousData);
        this.params.api.stopEditing(true);
        this.updateAndCancelCleanUp.call(this);
    }

    onDeleteClick() {
        const selectedData = [this.params.node.data];
        this.params.api.applyTransaction({ remove: selectedData });
    }

    updateAndCancelCleanUp() {
        this.eGui.removeChild(this.updateButton);
        this.eGui.removeChild(this.cancelButton);
        this.eGui.appendChild(this.editButton);
        this.eGui.appendChild(this.deleteButton);
    }

    editCleanUp() {
        this.eGui.appendChild(this.updateButton);
        this.eGui.appendChild(this.cancelButton);
        this.eGui.removeChild(this.editButton);
        this.eGui.removeChild(this.deleteButton);
    }
}
